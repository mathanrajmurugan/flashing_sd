#!/bin/bash

#############################################################
# script che a partire dal codice prodotto:
#	Scarica o Agggiorna i precompilati di u-boot e kernel ed il File System
#	Li scrive su Scheda SD
#############################################################

###### PARAMETRI IN INGRESSO ####
# $1 = Product_Number [opzionale]
##################################

####################### CONFIG ################################
SERVER_BASE_URL="http://imx6-binary.seco.com/"
UBOOT_FOLDER="U-BOOT"
FILE_SYSTEM_FOLDER="FILE_SYSTEM"
KERNEL_FOLDER="KERNEL"
BOOTARG_FOLDER="BOOTARGS"			

VERSION_FILE="version.txt"
FILE_SYSTEM_LIST="File_System_List.txt"

KERNEL="KERNEL_SECO_3.14.28.tar.gz"

#FILE_SYSTEM="FS_PROVA.tar.gz"
LOCAL_PATH="$PWD/seco_bin"	


#############################################################

####################### CONSTANT ###########################
#		928		#

#* UBOOT 928 QUAD START FROM MMC *#
UBOOT_928_QUAD_512MB="u-boot-Q7-QD-512MB-2014.imx"
UBOOT_928_QUAD_1024MB="u-boot-Q7-QD-256MBx4-2014.imx"
UBOOT_928_QUAD_2048MB="u-boot-Q7-QD-2GB-2014.imx"
UBOOT_928_QUAD_4096MB="u-boot-Q7-QD-4GB-2014.imx"

#* UBOOT 928 DUAL LITE START FROM MMC *#
UBOOT_928_DL_512MB="u-boot-Q7-DL-512MB-2014.imx"
UBOOT_928_DL_1024MB="u-boot-Q7-DL-256MBx4-2014.imx"
UBOOT_928_DL_2048MB="u-boot-Q7-DL-2GB-2014.imx"
UBOOT_928_DL_4096MB="u-boot-Q7-DL-4GB-2014.imx"

#* UBOOT 928 SOLO START FROM MMC *#
UBOOT_928_SOLO_512MB="u-boot-Q7-S-512MB-2014.imx"
UBOOT_928_SOLO_1024MB="u-boot-Q7-S-512MBx2-2014.imx"
#############  FINO  A QUI  #############

#               962             #

#* UBOOT 962 QUAD START FROM MMC *#
UBOOT_962_QUAD_512MB="u-boot-uQ7-QD-512MB-2014.imx"
UBOOT_962_QUAD_1024MB="u-boot-uQ7-QD-256MBx4-2014.imx"
UBOOT_962_QUAD_2048MB="u-boot-uQ7-QD-2GB-2014.imx"

#* UBOOT 962 DUAL LITE START FROM MMC *#
UBOOT_962_DL_512MB="u-boot-uQ7-DL-512MB-2014.imx"
UBOOT_962_DL_1024MB="u-boot-uQ7-DL-256MBx4-2014.imx" 
UBOOT_962_DL_2048MB="u-boot-uQ7-DL-2GB-2014.imx"

#* UBOOT 962 SOLO START FROM MMC *#
UBOOT_962_SOLO_512MB="u-boot-uQ7-S-512MB-2014.imx"
UBOOT_962_SOLO_1024MB="u-boot-uQ7-S-512MBx2-2014.imx"

#               984             #

#* UBOOT 984 QUAD START FROM MMC *#
UBOOT_984_QUAD_512MB="u-boot-uSBC-QD-512MB-2014.imx"
UBOOT_984_QUAD_1024MB="u-boot-uSBC-QD-256MBx4-2014.imx"
UBOOT_984_QUAD_2048MB="u-boot-uSBC-QD-2GB-2014.imx"

#* UBOOT 984 DUAL LITE START FROM MMC *#
UBOOT_984_DL_512MB="u-boot-uSBC-DL-512MB-2014.imx"
UBOOT_984_DL_1024MB="u-boot-uSBC-DL-256MBx4-2014.imx"
UBOOT_984_DL_2048MB="u-boot-uSBC-DL-2GB-2014.imx"

#* UBOOT 984 SOLO START FROM MMC *#
UBOOT_984_SOLO_512MB="u-boot-uSBC-S-512MB-2014.imx"
UBOOT_984_SOLO_1024MB="u-boot-uSBC-S-512MBx2-2014.imx"

#		A62		#

#* UBOOT A62 QUAD START FROM MMC *#
UBOOT_A62_QUAD_512MB="u-boot-a62-QD-512MB-2014.imx"
UBOOT_A62_QUAD_1024MB="u-boot-a62-QD-256MBx4-2014.imx"
UBOOT_A62_QUAD_2048MB="u-boot-a62-QD-2GB-2014.imx"

#* UBOOT A62 DUAL LITE START FROM MMC *#
UBOOT_A62_DL_512MB="	u-boot-a62-DL-512MB-2014.imx"
UBOOT_A62_DL_1024MB="u-boot-a62-DL-256MBx4-2014.imx"
UBOOT_A62_DL_2048MB="u-boot-a62-DL-2GB-2014.imx"

#* UBOOT A62 SOLO START FROM MMC *#
UBOOT_A62_SOLO_512MB="u-boot-a62-S-512MB-2014.imx"
UBOOT_A62_SOLO_1024MB="u-boot-a62-S-256MBx4-2014.imx"
UBOOT_A62_SOLO_2048MB=""

#		A75			#

#* UBOOT A75 SOLO START FROM MMC *#
UBOOT_A75_SOLO_256MB="u-boot-a75-S-256MB-2014.imx"

#* UBOOT A75 DUAL LITE START FROM MMC *#
UBOOT_A75_DL_512MB="u-boot-a75-DL-512MB-2014.imx"
UBOOT_A75_DL_1024MB=""


################################################################

BOOT_ARGS_QD_928="boot_args_QD_928.bin"		# per Quad
BOOT_ARGS_DL_928="boot_args_DL_928.bin"		# per Dual Lite e Solo

BOOT_ARGS_QD_962="boot_args_QD_962.bin"		# per Quad
BOOT_ARGS_DL_962="boot_args_DL_962.bin"		# per Dual Lite e Solo

BOOT_ARGS_QD_984=""		# per Quad
BOOT_ARGS_DL_984=""		# per Dual Lite e Solo

BOOT_ARGS_QD_A62="boot_args_QD_A62.bin"		# per Quad
BOOT_ARGS_DL_A62="boot_args_DL_A62.bin"		# per Dual Lite e Solo

BOOT_ARGS_S_A75="boot_args_DL_A75.bin"		# per Solo
BOOT_ARGS_DL_A75="boot_args_DL_A75.bin"		# per Dual Lite 


#################################################################


parseCode() {

	if [ "$CODE" == "SYS-A62-SOLO-CSCW" ]; then
		CODE="SA62-3121-5130-C0"
	fi
	if [ "$CODE" == "SYS-A62-LITE-CSCW" ]; then
		CODE="SA62-1221-5250-C0"
	fi
	if [ "$CODE" == "SYS-A62-QUAD-CLCW" ]; then
		CODE="SA62-2221-4240-C0"
	fi
	
	#estraggo le informazioni dal S/N
	BOARD_TYPE=${CODE:1:3}
	BOARD=""
	CPU=${CODE:5:1}
	RAM_SIZE=${CODE:6:1}
	MMC_SIZE=${CODE:7:1}
	CAN_EN=${CODE:0:1}

	
if [ "$BOARD_TYPE" == "928" ]; then


case "$CPU" in
	
	2 | B | C | D | E | F | R | T | V | W | Y ) 

		echo "Board Type iMX6 928 QUAD DUAL setting right uboot. . ."
		case "$RAM_SIZE" in
			1)
			   echo "RAM: 512MB"
			   RAM="512MB"
			   UBOOT=$UBOOT_928_QUAD_512MB
			   ;;
			3)
			   echo "RAM: 1GB"
			   RAM="1GB"
			   UBOOT=$UBOOT_928_QUAD_1024MB
			   ;;
			5)
			   echo "RAM: 2GB"
			   RAM="2GB"
			   UBOOT=$UBOOT_928_QUAD_2048MB
			   ;;
			6)
			   echo "RAM: 4GB"
			   RAM="4GB"
			   UBOOT=$UBOOT_928_QUAD_4096MB
			   ;;
			*)
			   echo "Error -> $opt: invalid RAM parameter"
			   exit 1;
		esac
	;;
	
	H | K | N | P | X )

                echo "Board Type iMX6 928 DUAL LITE setting right uboot. . ."
                case "$RAM_SIZE" in
                        1)
                           echo "RAM: 512MB"
                           RAM="512MB"
                           UBOOT=$UBOOT_928_DL_512MB
                           ;;
                        3)
                           echo "RAM: 1GB"
                           RAM="1GB"
                           BOOT=$UBOOT_928_DL_1024MB
                           ;;
                        5)
                           echo "RAM: 2GB"
                           RAM="2GB"
                           UBOOT=$UBOOT_928_DL_2048MB
                           ;;
                        6)
                           echo "RAM: 4GB"
                           RAM="4GB"
                           UBOOT=$UBOOT_928_DL_4096MB
                           ;;
                        *)
                           echo "Error -> $opt: invalid RAM parameter"
                           exit 1;
                esac
        ;;

	1 | G | L | M )

                echo "Board Type iMX6 928 SOLO setting right uboot. . ."
                case "$RAM_SIZE" in
                        1)
                           echo "RAM: 512MB"
                           RAM="512MB"
                           UBOOT=$UBOOT_928_SOLO_512MB
                           ;;
                        2)
                           echo "RAM: 1GB"
                           RAM="1GB"
                           UBOOT=$UBOOT_928_SOLO_1024MB
                           ;;
                        4)
                           echo "RAM: 2GB but used 1GB"
                           RAM="1GB"
                           UBOOT=$UBOOT_928_SOLO_1024MB
                           ;;
			*)
                           echo "Error -> $opt: invalid RAM parameter"
                           exit 1;
                esac
        ;;
	
	* )
	    echo "Error invalid CPU type  -> $CPU "
	    exit 1;

esac

elif [ "$BOARD_TYPE" == "962" ]; then


case "$CPU" in

        1 | 2 | 3 | 4 | 5 | E | F | G | H | L | R )

                echo "Board Type iMX6 962 QUAD DUAL setting right uboot. . ."
                case "$RAM_SIZE" in
                        A)
                           echo "RAM: 512MB"
                           RAM="512MB"
                           UBOOT=$UBOOT_962_QUAD_512MB
                           ;;
                        1)
                           echo "RAM: 1GB"
                           RAM="1GB"
                           UBOOT=$UBOOT_962_QUAD_1024MB
                           ;;
                        2)
                           echo "RAM: 2GB"
                           RAM="2GB"
                           UBOOT=$UBOOT_962_QUAD_2048MB
                           ;;
                        *)
                           echo "Error -> $opt: invalid RAM parameter"
                           exit 1;
                esac
        ;;
	
	7 | 8 | B | C | K )

                echo "Board Type iMX6 962 DUAL LITE setting right uboot. . ."
                case "$RAM_SIZE" in
                        A)
                           echo "RAM: 512MB"
                           RAM="512MB"
                           UBOOT=$UBOOT_962_DL_512MB
                           ;;
                        1)
                           echo "RAM: 1GB"
                           RAM="1GB"
                           UBOOT=$UBOOT_962_DL_1024MB
                           ;;
                        2)
                           echo "RAM: 2GB"
                           RAM="2GB"
                           UBOOT=$UBOOT_962_DL_2048MB
                           ;;
                        *)
                           echo "Error -> $opt: invalid RAM parameter"
                           exit 1;
                esac
        ;;

	6 | 9 | A | P )

                echo "Board Type iMX6 962 SOLO setting right uboot. . ."
                case "$RAM_SIZE" in
                        A)
                           echo "RAM: 512MB"
                           RAM="512MB"
                           UBOOT=$UBOOT_962_SOLO_512MB
                           ;;
                        1)
                           echo "RAM: 1GB"
                           RAM="1GB"
                           UBOOT=$UBOOT_962_SOLO_1024MB
                           ;;
                        2)
                           echo "RAM: 2GB"
                           RAM="2GB"
                           UBOOT=$UBOOT_962_SOLO_2048MB
                           ;;
                        *)
                           echo "Error -> $opt: invalid RAM parameter"
                           exit 1;
                esac
        ;;

	* )
         	echo "Error invalid CPU type  -> $CPU "
            	exit 1;
	
esac


elif [ "$BOARD_TYPE" == "984" ]; then

	if [ "$CPU" == "1" ]; then

	echo "Board Type iMX6 SOLO -> S984"

	BOARD="SB"

	case "$RAM_SIZE" in
		1) 
		   echo "RAM: 512MB"
		   RAM="512MB"
		   UBOOT=$SUBOOT_984_SOLO_512MB
		   ;;
		2) 
                   echo "RAM: 1GB"
		   RAM="1GB"
		   UBOOT=$UBOOT_984_SOLO_1024MB
		   ;;
                4) 
                   echo "RAM: 2GB"
                   RAM="2GB"
		   UBOOT=$UBOOT_984_SOLO_2048MB
		   ;;
		*) 
		   echo "Error -> $opt: invalid RAM parameter"
		   exit 1;	 
	esac

      elif [ "$CPU" == "2" ]; then

        echo "Board Type iMX6 DUAL/LITE -> S984"

	BOARD="SB"

	case "$RAM_SIZE" in
                1) 
                   echo "RAM: 512MB"
                   RAM="512MB"
		   UBOOT=$UBOOT_984_DL_512MB
		   ;;
                3) 
                   echo "RAM: 1GB"
		   RAM="1GB"
		   UBOOT=$UBOOT_984_DL_1024MB
		   ;;
                4) 
                   echo "RAM: 2GB"
		   RAM="2GB"
		   UBOOT=$UBOOT_984_DL_2048MB
		   ;;
                *) 
                   echo "Error -> $opt: invalid RAM parameter"
                   exit 1;       
        esac

      elif [ "$CPU" == "3" ] || [ "$CPU" == "4" ]; then

	echo "Board Type iMX6 QUAD/DUAL -> S984" 

	BOARD="SB"

	case "$RAM_SIZE" in
        	1)
		   echo "RAM: 512MB"
                   RAM="512MB"
		   UBOOT=$UBOOT_984_QUAD_512MB
		   ;;
                3)
                   echo "RAM: 1GB"
		   RAM="1GB"
		   UBOOT=$BOOT_984_QUAD_1024MB
		   ;;
                4)
                   echo "RAM: 2GB"
		   RAM="2GB"
		   UBOOT=$UBOOT_984_QUAD_2048MB
		   ;;
                *)
                   echo "Error -> $opt: invalid RAM parameter"
                   exit 1;
	esac


	else 
	
		echo "Error -> $opt: invalid BOARD parameter"
                exit 1;

	fi
		

elif [ "$BOARD_TYPE" == "A62" ]; then

        if [ "$CPU" == "3" ]; then

        echo "Board Type iMX6 SOLO -> A62"

        BOARD="A62"

        case "$RAM_SIZE" in
                1)
                   echo "RAM: 512MB"
                   RAM="512MB"
                   UBOOT=$UBOOT_A62_SOLO_512MB
                   ;;
                2)
                   echo "RAM: 1GB"
                   RAM="1GB"
                   UBOOT=$UBOOT_A62_SOLO_1024MB
                   ;;
                3)
                   echo "RAM: 2GB"
                   RAM="2GB"
                   UBOOT=$BOOT_A62_SOLO_2048MB
                   ;;
                *)
                   echo "Error -> $opt: invalid RAM parameter"
                   exit 1;
        esac
	
	fi	

        if [ "$CPU" == "2" ]; then

        echo "Board Type iMX6 QUAD -> A62"

        BOARD="A62"

        case "$RAM_SIZE" in		
		1)
                   echo "RAM: 512MB"
                   RAM="512MB"
                   UBOOT=$UBOOT_A62_QUAD_512MB
                   ;;
                2)
                   echo "RAM: 1GB"
                   RAM="1GB"
                   UBOOT=$UBOOT_A62_QUAD_1024MB
                   ;;
                3)
                   echo "RAM: 2GB"
                   RAM="2GB"
                   UBOOT=$UBOOT_A62_QUAD_2048MB
                   ;;
                *)
                   echo "Error -> $opt: invalid RAM parameter"
                   exit 1;
        esac

     fi

     if [ "$CPU" == "1" ]; then

        echo "Board Type iMX6 DUAL/LITE -> A62"

        BOARD="A62"

        case "$RAM_SIZE" in
                1)
                   echo "RAM: 512MB"
                   RAM="512MB"
                   UBOOT=$UBOOT_A62_DL_512MB
                   ;;
                2)
                   echo "RAM: 1GB"
                   RAM="1GB"
                   UBOOT=$UBOOT_A62_DL_1024MB
                   ;;
                3)
                   echo "RAM: 2GB"
                   RAM="2GB"
                   UBOOT=$UBOOT_A62_DL_2048MB
                   ;;
                *)
                   echo "Error -> $opt: invalid RAM parameter"
                   exit 1;
        esac
	
	fi

elif [ "$BOARD_TYPE" == "A75" ]; then

	BOARD="A75"
	if [ "$CPU" == "1" ]; then
		echo "Board Type iMX6 SOLO -> A75"

		case "$RAM_SIZE" in
			1)
			echo "RAM: 256MB"
			RAM="256MB"
			UBOOT=${UBOOT_A75_SOLO_256MB}
			;;
			*)
			echo "Error -> $opt: invalid RAM parameter"
			exit 1;
		esac
	
	fi	
	if [ "$CPU" == "2" ]; then

		echo "Board Type iMX6 DUAL/LITE -> A75"

		case "$RAM_SIZE" in
			3)
			echo "RAM: 512MB"
			RAM="512MB"
			UBOOT=${UBOOT_A75_DL_512MB}
			;;
			4)
			echo "RAM: 1GB"
			RAM="1GB"
			UBOOT=${UBOOT_A75_DL_1024MB}
			;;
			*)
			echo "Error -> $opt: invalid RAM parameter"
			exit 1;
		esac
	fi
fi


}

parseBoot_Args()
	{
			
	if [ "$BOARD_TYPE" == "928" ]; then
		case "$CPU" in

			2 | B | C | D | E | F | R | T | V | W | Y ) 		# 928 quad
				BOOT_ARGS=${BOOT_ARGS_QD_928}
			;;
			H | K | N | P | X | 1 | G | L | M )			# 928 Dual Lite or Solo
				BOOT_ARGS=${BOOT_ARGS_DL_928}
			;;
			*)
				echo "echo Error invalid CPU type  -> $CPU "
				exit 1
		esac
		
	elif [ "$BOARD_TYPE" == "962" ]; then
		case "$CPU" in

			1 | 2 | 3 | 4 | 5 | E | F | G | H | L | R )		# 962 Quad
				BOOT_ARGS=${BOOT_ARGS_QD_962}
			;;
			H7 | 8 | B | C | K | 6 | 9 | A | P )			# 962 Dual Lite or Solo
				BOOT_ARGS=${BOOT_ARGS_DL_962}
			;;
			*)
				echo "echo Error invalid CPU type  -> $CPU "
				exit 1
		esac
		
	elif [ "$BOARD_TYPE" == "A62" ]; then
		case "$CPU" in
			2 )								# A62 Quad
				BOOT_ARGS=${BOOT_ARGS_QD_A62}
			;;
			1 | 3 )							# A62 Dual Lite or Solo
				BOOT_ARGS=${BOOT_ARGS_DL_A62}
			;;
			*)
				echo "echo Error invalid CPU type  -> $CPU "
				exit 1
		esac
	
	elif [ "$BOARD_TYPE" == "984" ]; then
		case "$CPU" in
			3 | 4 )							# 984 Quad
				BOOT_ARGS=${BOOT_ARGS_QD_984}
			;;
			1 | 2 )							# 984 Dual Lite or Solo
				BOOT_ARGS=${BOOT_ARGS_DL_984}
			;;
			*)
				echo "echo Error invalid CPU type  -> $CPU "
				exit 1
		esac
	
	elif [ "$BOARD_TYPE" == "A75" ]; then
		case "$CPU" in
			1 )							# A75 Solo
				BOOT_ARGS=${BOOT_ARGS_S_A75}
			;;
			2)							# A75 Dual Lite
				BOOT_ARGS=${BOOT_ARGS_DL_A75}
			;;
			*)
				echo "echo Error invalid CPU type  -> $CPU "
				exit 1
		esac
	fi
	
	echo "BOOTARGS FILE: $BOOT_ARGS "
	}




#########################################################################################################################################



if (( $# == 1 )); then
    CODE=$1	
else
    #echo "Please specify your product number"
    read -p "Please specify your product number:  " CODE
fi


whois=$(whoami)
if [ "$whois" != "root" ]; then
	echo "You need to be root. Exit"
	exit 1
fi


parseCode		
parseBoot_Args	



# Controllo parametri
aux=${SERVER_BASE_URL:${#SERVER_BASE_URL}-1}	
if [ $aux == '/' ]; then
    SERVER_BASE_URL=${SERVER_BASE_URL:0:${#SERVER_BASE_URL}-1}
fi
aux=${LOCAL_PATH:${#LOCAL_PATH}-1}
if [ $aux == '/' ]; then
    LOCAL_PATH=${LOCAL_PATH:0:${#LOCAL_PATH}-1}
fi

##################### CHOOSING FILE SYSTEM ##################

mkdir -p $LOCAL_PATH
FS_Update="0"
     wget ${SERVER_BASE_URL}/${FILE_SYSTEM_FOLDER}/${FILE_SYSTEM_LIST} -O ${LOCAL_PATH}/FS_list.txt
     if [ "$?" -eq "0" ];then
	    if [ -f ${LOCAL_PATH}/FS_list.txt ];then
		   clear
		  Last_Path=$PWD
		  cd ${LOCAL_PATH}
		   FS=$(cat ${LOCAL_PATH}/FS_list.txt)

		   echo "  "
		   echo "  "
		   echo "-----------------------------------------------------"
		   echo "File System Options are:"
		   echo "  "
		   echo "$FS"
		   echo "  "
		   echo "-----------------------------------------------------"
		   read -p "Which File System would you like to use?   " FILE_SYSTEM

		   aux=$(find  $LOCAL_PATH -iname $FILE_SYSTEM)
		   if [ "$aux" == "" ]; then
			   FS_Available="0"
		   else
			   FS_Available="1"
		   fi
		   cd $Last_Path
		   
	    fi
    else
	    clear
	    echo "WARNING: Unable  to retrieve the File System downlaod page!!!"
	    echo "Choosing from local file in ${LOCAL_PATH}"
	    echo "  "
	    Last_Path=$PWD
	    cd ${LOCAL_PATH}
	    ls *tar.gz > FS_list.txt
	    find ./ -iname "FS_list.txt" -exec sed -i "s/${KERNEL}/ /g" {} \;
	    FS=$(cat ${LOCAL_PATH}/FS_list.txt)
	    cd $Last_Path
	    if [ "$FS" == "" ];then
		   echo "No file system available. Exit!!!"
		   exit 1
	    else
		   echo "  "
		   echo "  "
		   echo "-----------------------------------------------------"
		   echo "File System Options are:"
		   echo "  "
		   echo "$FS"
		   echo "  "
		   echo "-----------------------------------------------------"
		   read -p "Which File System would you like to use?   " FILE_SYSTEM
		   FS_Available="1"
	    fi
    fi

echo "--------------------------------"
echo "FILE SYSTEM : $FILE_SYSTEM" 
echo "--------------------------------"    


#####################   CHECK UPDATES #######################

Update_Available="0"
echo "Checking for update.."
mkdir -p $LOCAL_PATH
chmod -R 777 $LOCAL_PATH
if [ -f $LOCAL_PATH/${CODE} ];then

    aux="${LOCAL_PATH}/${CODE}"
    Local_File=$(cat $aux)
    cat $aux	
    if [ "$?" -ne "0" ];then
	    $Local_File="empty"
    fi
    wget $SERVER_BASE_URL/$VERSION_FILE -O $LOCAL_PATH/temp.txt
    if [ "$?" -ne "0" ];then
	    echo "WARNING: Cannot retrieve the downlaod page!!!"
	    Remote_File=""
    else
	    tmp="${LOCAL_PATH}/temp.txt"
	    Remote_File=$(cat ${tmp})
	    aux="$LOCAL_PATH/${CODE}"
	    rm -f $aux
	    echo "$Remote_File" > ${LOCAL_PATH}/${CODE}
	    echo "-----------------------------------"
	    echo "LOCAL VERSION: $Local_File "
	    echo "LAST VERSION:  $Remote_File"	    
	    echo "-----------------------------------"
	    if [ "$Local_File" == "$Remote_File" ]; then
		 clear
		 echo "-----------------------------------"
	        echo "Your files are already updated!"
		 echo "-----------------------------------"
	    else
		 echo "-----------------------------------"
		 echo "New updates was found..."
		 echo "-----------------------------------"
		 Update_Available="1"
	    fi
    fi

else
	clear
	echo "---------------------------------------------------"
	echo "All files will be now downloaded, please wait . . ." 
	echo "---------------------------------------------------"
	Update_Available="1"
	wget ${SERVER_BASE_URL}/${VERSION_FILE} -O ${LOCAL_PATH}/${CODE}
fi

sleep 3

############## DOWNLOAD AGGIORNAMENTI ############################
if [ "$Update_Available" == "1" ]; then
    clear
    echo "------------------------------------------"
    echo "Downloading updates. This can take time..."	
    echo "------------------------------------------"
    mkdir -p $LOCAL_PATH

    # Uboot
    wget ${SERVER_BASE_URL}/${UBOOT_FOLDER}/$UBOOT -O ${LOCAL_PATH}/uboot.tmp
    if [ "$?" -ne "0" ]; then
	    rm -f ${LOCAL_PATH}/uboot.tmp
           if [ -f ${LOCAL_PATH}/$UBOOT ];then
			echo "WARNING: Cannot update U-BOOT! Using the old version"
	    else
			echo "----------------------------------------------------------"
		       echo "Cannot download U-BOOT and no old local version foud! Exit"
			echo "----------------------------------------------------------"
			rm -f $LOCAL_PATH/uboot.tmp
			exit 1
	    fi
    else

	    rm -f ${LOCAL_PATH}/$UBOOT
	    mv ${LOCAL_PATH}/uboot.tmp ${LOCAL_PATH}/$UBOOT
    fi
    # Kernel
    wget ${SERVER_BASE_URL}/${KERNEL_FOLDER}/${KERNEL} -O ${LOCAL_PATH}/kernel.tmp
    if [ "$?" -ne "0" ];then
	    rm -f ${LOCAL_PATH}/kernel.tmp
           if [ -f ${LOCAL_PATH}/$KERNEL ];then
			echo "WARNING: Cannot update KERNEL! Using the old version"	
	    else
			echo "------------------------------------------"
		       echo "Cannot download KERNEL and no old local version foud! Exit"
			echo "------------------------------------------"
			rm -f $LOCAL_PATH/kernel.tmp
			exit 1
	    fi
    else

	    rm -f $LOCAL_PATH/$KERNEL
	    mv ${LOCAL_PATH}/kernel.tmp ${LOCAL_PATH}/$KERNEL
    fi
    cd ..
else
	    echo "------------------------------------------"
	    echo "Your files are already updated!"
	    echo "------------------------------------------"
fi
 
 
    # File System
if [ "$FS_Available" == "0" ]; then
    clear
    echo "------------------------------------------"
    echo "Downloading File System ..."	
    echo "------------------------------------------"
    wget ${SERVER_BASE_URL}/${FILE_SYSTEM_FOLDER}/${FILE_SYSTEM}  -O ${LOCAL_PATH}/fs.tmp
    if [ "$?" -ne "0" ];then
	    rm -f ${LOCAL_PATH}/fs.tmp
           if [ -f ${LOCAL_PATH}/$FILE_SYSTEM ];then
	    echo "WARNING: Cannot update FILE SYSTEM! Serching for a local version"	
	    else
		       echo "------------------------------------------"
			echo "Cannot download FILE SYSTEM and no old local version foud! Exit"
			echo "------------------------------------------"
			rm -f $LOCAL_PATH/fs.tmp
			exit 1	
	    fi
    else

	    rm -f ${LOCAL_PATH}/$FILE_SYSTEM
	    mv ${LOCAL_PATH}/fs.tmp ${LOCAL_PATH}/$FILE_SYSTEM
    fi
fi


# Bootargs
if [ -f ${LOCAL_PATH}/${BOOT_ARGS} ];then

	echo "U-BOOT_ARGS image: ${LOCAL_PATH}/${BOOT_ARGS}"
else

	wget ${SERVER_BASE_URL}/${BOOTARG_FOLDER}/${BOOT_ARGS} -O ${LOCAL_PATH}/${BOOT_ARGS}.tmp
	if [ "$?" -eq "0" ];then
		mv ${LOCAL_PATH}/${BOOT_ARGS}.tmp ${LOCAL_PATH}/${BOOT_ARGS}
	else
		echo "WARNING: Cannot download bootargs!"
		rm ${LOCAL_PATH}/${BOOT_ARGS}.tmp
	fi
fi

 
##################### PREPARAZIONE SCHEDA SD ############################
Risposta='n'
clear
while [ "$Risposta" != 'y' ]; do
    read -p "Please select the device you would like to flash (es. /dev/sdx):  " Device
    read -p "This will totally erase the content of device $Device. Are you sure you want to continue? (y/n):  " Risposta
done

uno="1"
due="2"
Device1=${Device}$uno
Device2=${Device}$due


Dimensione=$(blockdev --getsize64 $Device)
if [ "$?" -eq "1" ];then
        echo "Cannot stat the devices! Exit"
        exit 1
fi
if [ $Dimensione -gt 34359738368 ]; then
    echo "You have probably choose the wrong device! Exit in order to prevent damage to your system"
    exit 1
fi


# flashing device
echo "Formatting $Device. This make take some minutes..."
umount $Device*
sleep 3
dd if=/dev/zero of=$Device bs=512 count=2048
if [ "$?" -eq "1" ];then
	echo "Error Flashing! Exit!"
	exit 1
fi 
sleep 2
sync
echo "Devices successfully formatted!"



##############################  tabella delle partizioni ############################## 
umount $Device*
sleep 3

(echo o; echo n; echo p; echo 1; echo ; echo +50M; echo w) | fdisk $Device

sleep 3
sync
umount $Device*
sleep 3
(echo n; echo p; echo 2; echo ; echo ; echo w) | fdisk $Device
sleep 1
(echo t; echo 1; echo b; echo t; echo 2; echo 83; echo w) | fdisk $Device

sleep 3
umount $Device*
sleep 3
mkfs.vfat $Device1
sleep 3
mkfs.ext4 $Device2
if [ "$?" -ne "0" ];then
	echo "Unable to create partition"
	exit 1
fi
sync
sleep 3


############################## u-boot #####################################################

umount $Device*
sleep 3
echo "U-BOOT Image: $LOCAL_PATH/$UBOOT"
echo "Flashing u-boot.  This make take some minutes..."
aux="$LOCAL_PATH/$UBOOT"
dd if=$aux of=$Device bs=512 seek=2				
if [ "$?" -eq "1" ];then
	echo "Error Flashing u-boot! Exit!"
	exit 1
fi 
sleep 3
sync
echo "U-boot successfully written!"

# bootargs
umount $Device*
sleep 3


if [ -f ${LOCAL_PATH}/${BOOT_ARGS} ]; then
	echo "U-BOOT_ARGS image: ${LOCAL_PATH}/${BOOT_ARGS}"
	echo "Setting u-boot bootargs . . ."
	aux="${LOCAL_PATH}/${BOOT_ARGS}"
	dd if=$aux of=$Device bs=512 seek=1024 count=1023
		if [ "$?" -eq "1" ];then
			echo "WARNING: Error setting bootargs!"
		fi 
else
	echo "WARNING: Cannot stat bootargs image!"
fi

sync


############################## Kernel #######################################################
mkdir -p $LOCAL_PATH/mount_tmp
umount $Device*
mount  $Device1 $LOCAL_PATH/mount_tmp/
sleep 3
echo "Flashing kernel. This can take some minutes..."
echo "$LOCAL_PATH/mount_tmp"
if [ "$?" -eq "1" ];then
        echo "Error Creating Folder tree! Exit!"
        exit 1
fi


tar zxpf $LOCAL_PATH/$KERNEL -C $LOCAL_PATH/mount_tmp ./boot/
if [ "$?" -eq "1" ];then
        echo "Error Copying Kernel! Exit!"
        exit 1
fi
sync
sleep 2
mv $LOCAL_PATH/mount_tmp/boot/* $LOCAL_PATH/mount_tmp/
echo "Kernel successfully written!"



############################ file system ##################################################
umount $Device*
mkdir -p ${LOCAL_PATH}/mount_tmp
mount $Device2 ${LOCAL_PATH}/mount_tmp/
sleep 3
echo "Copying Root File System. This can take some minutes..."
tar zxpf ${LOCAL_PATH}/${FILE_SYSTEM} -C ${LOCAL_PATH}/mount_tmp
if [ "$?" -eq "1" ];then
        echo "Error Copying File System! Exit!"
        exit 1
fi
sync
sleep 5
echo "File system successfully written!"
umount $Device*

############################### operazioni finali #########################################
echo ""
echo ""
echo "****************************************************"
echo "**** YOUR BOOTABLE SD WAS SUCCESSFULLY CREATED! ****"
echo "****************************************************"
echo ""
echo ""


exit



